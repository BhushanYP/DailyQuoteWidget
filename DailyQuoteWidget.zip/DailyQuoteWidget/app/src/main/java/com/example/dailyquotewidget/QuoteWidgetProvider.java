package com.example.dailyquotewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class QuoteWidgetProvider extends AppWidgetProvider {

    private static final String ACTION_WIDGET_TAP = "com.example.quotewidget.ACTION_WIDGET_TAP";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // Loop through all widget instances
        for (int appWidgetId : appWidgetIds) {
            // Create an Intent to update the widget on tap
            Intent intent = new Intent(context, QuoteWidgetProvider.class);
            intent.setAction(ACTION_WIDGET_TAP);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            // Get the current widget layout
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
            // Set up the click action on the widget
            views.setOnClickPendingIntent(R.id.widget_layout, pendingIntent);

            // Update the widget with the new quote and author
            updateWidgetQuote(context, views);

            // Notify AppWidgetManager to update the widget
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_WIDGET_TAP.equals(intent.getAction())) {
            // When the widget is tapped, update the quote
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            int[] appWidgetIds = appWidgetManager.getAppWidgetIds(new ComponentName(context, QuoteWidgetProvider.class));

            for (int appWidgetId : appWidgetIds) {
                RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
                updateWidgetQuote(context, views);
                appWidgetManager.updateAppWidget(appWidgetId, views);
            }
        }
    }

    private void updateWidgetQuote(Context context, RemoteViews views) {
        // Example quotes list (can be extended)
        String[] quotes = new String[]{
                "The only way to do great work is to love what you do. - Steve Jobs",
                "The best way to predict the future is to create it. - Peter Drucker",
                "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
                "You miss 100% of the shots you don’t take. - Wayne Gretzky",
                "Believe you can and you're halfway there. - Theodore Roosevelt",
                "Don’t watch the clock; do what it does. Keep going. - Sam Levenson",
                // Add more quotes here
        };

        // Randomly select a quote
        int randomIndex = (int) (Math.random() * quotes.length);
        String selectedQuote = quotes[randomIndex];
        String[] quoteParts = selectedQuote.split(" - ");
        String quoteText = quoteParts[0];
        String authorText = quoteParts[1];

        // Set the quote and author text on the widget
        views.setTextViewText(R.id.quote_text, quoteText);
        views.setTextViewText(R.id.author_text, authorText);
    }
}