package com.example.dailyquotewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetProvider;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.util.Random;

public class WidgetProvider extends AppWidgetProvider {

    private static final String[] QUOTES = {
            "The only way to do great work is to love what you do. – Steve Jobs",
            "Success is not final, failure is not fatal: It is the courage to continue that counts. – Winston Churchill",
            "You miss 100% of the shots you don’t take. – Wayne Gretzky",
            "The future belongs to those who believe in the beauty of their dreams. – Eleanor Roosevelt",
            "It does not matter how slowly you go as long as you do not stop. – Confucius",
            "Believe you can and you're halfway there. – Theodore Roosevelt",
            "The best way to predict the future is to create it. – Peter Drucker",
            "What lies behind us and what lies before us are tiny matters compared to what lies within us. – Ralph Waldo Emerson",
            "Hardships often prepare ordinary people for an extraordinary destiny. – C.S. Lewis",
            "The harder you work for something, the greater you'll feel when you achieve it. – Unknown",
            "Success is the sum of small efforts, repeated day in and day out. – Robert Collier",
            "If you can dream it, you can do it. – Walt Disney",
            "It always seems impossible until it's done. – Nelson Mandela",
            "The only limit to our realization of tomorrow is our doubts of today. – Franklin D. Roosevelt",
            "Do what you can, with what you have, where you are. – Theodore Roosevelt",
            "Act as if what you do makes a difference. – William James",
            "Success is not how high you have climbed, but how you make a positive difference to the world. – Roy T. Bennett",
            "Our lives are what our thoughts make it. – Marcus Aurelius",
            "The only person you are destined to become is the person you decide to be. – Ralph Waldo Emerson",
            "It’s not whether you get knocked down, it’s whether you get up. – Vince Lombardi",
            "Everything you can imagine is real. – Pablo Picasso"
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            Intent intent = new Intent(context, WidgetProvider.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            Random random = new Random();
            String randomQuote = QUOTES[random.nextInt(QUOTES.length)];

            String[] parts = randomQuote.split("–");
            String quoteText = parts[0].trim();
            String authorText = parts.length > 1 ? parts[1].trim() : "Unknown";

            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
            views.setTextViewText(R.id.quoteTextView, quoteText);
            views.setTextViewText(R.id.authorTextView, authorText);
            views.setOnClickPendingIntent(R.id.widget_layout, pendingIntent);

            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) {
            onUpdate(context, AppWidgetManager.getInstance(context), new int[]{});
        }
    }
}